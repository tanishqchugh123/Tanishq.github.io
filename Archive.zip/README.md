# Portfolio_Template

Portfolio Website template for portfolio building workshop.


## HTML CSS Resources

[Microsoft Learn Learning Path](https://learn.microsoft.com/en-us/training/paths/build-web-pages-html-css-for-beginners/?WT.mc_id=studentamb_285271)

[Nishant's Cheatsheet](https://nishantattrey07.github.io/)
